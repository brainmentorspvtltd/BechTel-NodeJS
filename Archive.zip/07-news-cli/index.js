#!/usr/bin/env node

import chalk from 'chalk'; // Color
import {program} from 'commander'; // Command Line Solution
import figlet from 'figlet'; // Big Text
import inquirer from 'inquirer'; // Interactive Command Line
import {createSpinner} from 'nanospinner'; // Animated Spinner

(async function(){
    await bigText('THE NEWS WORLD ');
    buildSpinner();
    await wait();
    console.log(chalk.red('Hello User, Here you can Read Stock Market News, Sports News, Weather News etc '));


program.version('1.0.0').description('News Program');

// Building Own Commands
program.command('news <newsname>').alias('n').description('Type sports for Sport News , Type weather for weather news , Type share for market news').action((newsname)=>{
console.log('News Name ', newsname);


if(newsname == 'sports'){
    fetch('https://cricketdata.org/how-to-use-cricket-data-api.aspx')
    // DO API CALL (https://cricketdata.org/how-to-use-cricket-data-api.aspx)
    console.log('Sports News is ');
    // Use FootBall (Fake API)
    inquirer.prompt({name:'SportsName', type:'input', message:'C for Cricket and F for Football'}
       ).then(answers=>{
            console.log('Answers ',answers);
    }).catch(err=>{
        console.log('Input Error ', err);
    })
}
else
if(newsname == 'weather'){
    // https://openweathermap.org/current
    console.log('Weather news');
}
else
if(newsname == 'share'){
    //https://polygon.io/stocks?gclid=EAIaIQobChMImJOQrOfW9gIV3ZpmAh0DNAJmEAAYASAAEgJka_D_BwE
    console.log('Stock Market News is ');
}
});
program.parse(process.argv);
}());


function wait(){
    return new Promise((resolve, reject)=>{
        setTimeout(()=>resolve(''),4000);
    });
}

function bigText(str){
    return new Promise((resolve, reject)=>{
        figlet(str, (err, content)=>{
            if(err){
                reject('Some Error '+JSON.stringify(err));
            }
            else{
                console.log(content);
                resolve(content);
            }
        });
    })
   
}

function buildSpinner(){
    const spinner = createSpinner('Loading...').start()

setTimeout(() => {
  spinner.success()
}, 2000)
    


}


/*

node index.js news —version
node index.js news —help

sudo npm i -g .   // u must be on the the local dir

Now run the 
newsapp   // on command
newsapp —version
newsapp —help
newsapp news sports 
*/