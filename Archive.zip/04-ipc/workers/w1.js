const logic = require('../services/logic');
console.log("Worker1 Loaded ",process.pid);
process.on('message', num=>{
    const result = logic(num);
    console.log('Worker1 Rec the Number ',process.pid );
    process.send(result); // Send to the Parent Process
   
})