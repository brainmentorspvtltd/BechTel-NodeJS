const logic = require('../services/logic');
console.log("Worker2 Loaded ",process.pid);
process.on('message', num=>{
    const result = logic(num);
    console.log('Worker2 Rec the Number ',process.pid );
    process.send(result); // Send to the Parent Process
   
})