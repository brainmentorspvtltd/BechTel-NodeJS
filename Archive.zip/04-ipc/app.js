const express = require('express');
const cluster = require('cluster');
const cores = require('os').cpus().length;
//const cp = require('child_process');
if(cluster.isMaster){ 
    console.log('Master Process Id ', process.pid);
    // Now Master Process Fork the Child Process
    const worker1 = require('child_process').fork('./workers/w1');
    const worker2 = require('child_process').fork('./workers/w2');
    console.log('Child Process Id ', worker1.pid);
    console.log('Child Process Id ', worker2.pid);
    // Listen the Child Process Message in Parent 
    worker1.on('message',val=>{
       console.log('Rec Result From Worker1 ', worker1.pid, ' Result ', val);
    });
    worker2.on('message',val=>{
        console.log('Rec Result From Worker2 ', worker2.pid, ' Result ', val);
     });

     cluster.on('fork',worker=>{
      console.log('Online Call....', worker.process.pid);
      //console.log('Online Call ',worker);
      worker.on('message', num=>{
         if(num%2===0){
            worker1.send(num); // Calling Worker1 on Message 
         }
         else{
            worker2.send(num); //  Calling Worker2 on Message
         }
      })
     })


     let CONSUME_BY_CHILD_PROCESS_ABOVE = 2;
     for(let i = 0; i<cores-CONSUME_BY_CHILD_PROCESS_ABOVE;i++){
        let worker = cluster.fork();
        console.log('Worker Started on PID ', worker.process.pid);

     }
     console.log('Total Cores ', cores);
}
else{
   const app =express();
    app.use('/', require('./routes/route'));
    const server = app.listen(1234, err=>{
        if(err){
            console.log('Server Crash ', err);
        }
        else{
            console.log('Server Start ', server.address().port);
        }
    });
}
// for testing
//http://localhost:1234/?num=3
// http://localhost:1234/?num=2
