
# User Use Cases

> This is where all the use cases (application services) for the users subdomain belongs 

