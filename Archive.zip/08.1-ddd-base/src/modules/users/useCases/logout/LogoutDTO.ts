
export interface LogoutDTO {
  userId: string;
}