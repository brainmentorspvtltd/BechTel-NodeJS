
import { RefreshToken } from "../../domain/jwt";

export interface RefreshAccessTokenDTO {
  refreshToken: RefreshToken;
}