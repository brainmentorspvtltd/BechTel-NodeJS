
export interface DeleteUserDTO {
  userId: string;
}