
export interface GetUserByUserNameDTO {
  username: string;
}

