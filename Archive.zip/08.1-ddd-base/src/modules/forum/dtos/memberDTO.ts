
import { UserDTO } from "../../users/dtos/userDTO";

export interface MemberDTO {
  reputation: number;
  user: UserDTO;
}