
import { memberRouter } from "./member";
import { commentRouter } from "./comment";
import { postRouter } from "./post";

export {
  memberRouter,
  commentRouter,
  postRouter
}