
import { CommentId } from "../../../domain/commentId";

export interface UpdateCommentStatsDTO {
  commentId: CommentId;
}