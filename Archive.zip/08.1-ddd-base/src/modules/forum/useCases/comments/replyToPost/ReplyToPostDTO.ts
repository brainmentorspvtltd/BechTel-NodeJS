
export interface ReplyToPostDTO {
  slug: string;
  userId: string;
  comment: string;
}