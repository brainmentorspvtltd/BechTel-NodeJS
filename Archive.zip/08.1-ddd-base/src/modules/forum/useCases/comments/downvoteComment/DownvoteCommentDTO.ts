
export interface DownvoteCommentDTO {
  userId: string;
  commentId: string;
}
