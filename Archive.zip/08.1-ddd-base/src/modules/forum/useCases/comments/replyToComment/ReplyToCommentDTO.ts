
export interface ReplyToCommentDTO {
  slug: string;
  userId: string;
  comment: string;
  parentCommentId: string;
}