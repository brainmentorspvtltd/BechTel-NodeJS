
export interface GetCommentByCommentIdRequestDTO {
  commentId: string;
  userId?: string;
}