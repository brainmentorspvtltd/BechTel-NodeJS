
import { CommentDTO } from "../../../dtos/commentDTO";

export interface GetCommentByCommentIdResponseDTO {
  comment: CommentDTO;
}