
import { CommentDTO } from "../../../dtos/commentDTO";

export interface GetCommentsByPostSlugResponseDTO {
  comments: CommentDTO[];
}