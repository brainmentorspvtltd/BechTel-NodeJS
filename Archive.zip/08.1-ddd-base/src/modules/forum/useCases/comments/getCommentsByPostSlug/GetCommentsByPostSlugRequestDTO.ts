
export interface GetCommentsByPostSlugRequestDTO {
  slug: string;
  offset?: number;
  userId?: string;
}
