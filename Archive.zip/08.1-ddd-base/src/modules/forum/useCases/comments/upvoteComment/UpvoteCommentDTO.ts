
export interface UpvoteCommentDTO {
  userId: string;
  commentId: string;
}
