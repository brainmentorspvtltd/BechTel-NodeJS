
export interface GetRecentPostsRequestDTO {
  userId?: string;
  offset?: number;
}