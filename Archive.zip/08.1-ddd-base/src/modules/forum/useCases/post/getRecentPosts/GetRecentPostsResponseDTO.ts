
import { PostDTO } from "../../../dtos/postDTO";

export interface GetRecentPostsResponseDTO {
  posts: PostDTO[];
}