
export interface GetPopularPostsRequestDTO {
  offset?: number;
  userId?: string;
}