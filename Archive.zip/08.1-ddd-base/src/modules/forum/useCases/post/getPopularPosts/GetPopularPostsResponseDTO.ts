
import { PostDTO } from "../../../dtos/postDTO";

export interface GetPopularPostsResponseDTO {
  posts: PostDTO[];
}