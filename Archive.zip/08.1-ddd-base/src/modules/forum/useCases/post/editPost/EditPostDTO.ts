
export interface EditPostDTO {
  postId: string;
  title?: string;
  text?: string;
  link?: string;
}

