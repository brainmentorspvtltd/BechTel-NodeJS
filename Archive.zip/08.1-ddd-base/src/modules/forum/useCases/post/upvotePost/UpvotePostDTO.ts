
export interface UpvotePostDTO {
  userId: string;
  slug: string;
}
