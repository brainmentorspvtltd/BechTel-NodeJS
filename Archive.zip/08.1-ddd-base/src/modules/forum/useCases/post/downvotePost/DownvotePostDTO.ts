
export interface DownvotePostDTO {
  userId: string;
  slug: string;
}
