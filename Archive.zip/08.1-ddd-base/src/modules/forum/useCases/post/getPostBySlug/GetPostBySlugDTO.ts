
export interface GetPostBySlugDTO {
  slug: string;
}

