
export interface UpdatePostStatsDTO {
  postId: string;
}

