
export interface GetMemberByUserNameDTO {
  username: string;
}

