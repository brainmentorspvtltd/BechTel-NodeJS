
import { MemberDTO } from "../../../dtos/memberDTO";

export interface GetMemberByUserNameResponseDTO {
  member: MemberDTO;
}