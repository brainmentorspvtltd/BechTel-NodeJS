
export interface CreateMemberDTO {
  userId: string;
}

