
export type VoteType = 'UPVOTE' | 'DOWNVOTE';