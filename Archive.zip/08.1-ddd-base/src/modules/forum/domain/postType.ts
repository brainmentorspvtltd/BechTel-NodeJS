
export type PostType = 'text' | 'link';