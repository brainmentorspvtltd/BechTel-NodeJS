
import { PostService } from "./postService"

const postService = new PostService();

export { postService }