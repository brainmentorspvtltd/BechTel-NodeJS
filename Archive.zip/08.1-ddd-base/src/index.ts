
// Infra
import "./shared/infra/http/app"
import "./shared/infra/database/sequelize"

// Subscriptions
import "./modules/forum/subscriptions";

