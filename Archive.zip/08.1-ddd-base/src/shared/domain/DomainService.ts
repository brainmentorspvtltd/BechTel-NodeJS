
export interface DomainService {

}
