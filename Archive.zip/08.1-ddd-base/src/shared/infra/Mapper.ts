
export interface Mapper<T> {
  
}