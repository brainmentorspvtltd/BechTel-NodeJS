
> If we wanted to build an admin front-end, we could put it here.