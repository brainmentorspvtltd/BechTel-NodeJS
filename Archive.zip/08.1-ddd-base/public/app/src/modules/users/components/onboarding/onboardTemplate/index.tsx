
import OnboardTemplate from "./components/OnboardTemplate";

export {
  OnboardTemplate
}