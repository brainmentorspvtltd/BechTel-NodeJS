
export interface Member {
  username: string;
  reputation: number;
}