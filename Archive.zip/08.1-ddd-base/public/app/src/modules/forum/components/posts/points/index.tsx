
import Points from "./components/Points";

export {
  Points
}