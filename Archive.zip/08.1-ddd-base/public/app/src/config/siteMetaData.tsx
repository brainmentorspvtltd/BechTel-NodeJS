

const siteMetaData = {
  title: 'Domain-Driven Designers | A forum to discuss Domain-Driven Design'
}

export {
  siteMetaData
}