
import FullPageLoader from "./components/FullPageLoader";
import Loader from "./components/Loader";

export {
  FullPageLoader,
  Loader
}