
import React from 'react';
//@ts-ignore
import RLoader from 'react-loader-spinner'

const Loader = () => (
  <RLoader
    type="Rings"
    color="#6a69ff"
    height={100}
    width={100}
  />
)

export default Loader;