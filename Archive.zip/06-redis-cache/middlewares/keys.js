module.exports = {
  "redisHost": "127.0.0.1",
  "redisPort": 6379
}