const express = require('express');
const app = express();
const cors = require('cors');
app.use(cors());
app.get('/payment',(req, res)=>{
    res.send('Payment detail Service...');
})
const server =  app.listen(4321, err=>{
    if(err){
        console.log('Error in Payment Server Start ', err);
    }
    else{
        console.log('Payment Server Start ',server.address().port);
    }
})