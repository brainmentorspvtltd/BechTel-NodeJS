const express = require('express');
const cluster = require('cluster');
const os = require('os');
console.log('Is Master ', cluster.isMaster);
if(cluster.isMaster){
    // Approach - 1
    // cluster.fork(); // First Time , Because of the app.js file will be execute again to create worker instance.
    // // so to create 4 Worker Instance call cluster.fork 4 times
    // cluster.fork();
    // cluster.fork();
    // cluster.fork();

    // Approach-2 To Fork Dynamically Based on Number of Core Avaliable
    const TOTAL_CORES = os.cpus().length;
    console.log('Total Cores ', TOTAL_CORES);
    for(let i = 1   ; i<=TOTAL_CORES; i++){
        cluster.fork(); // First Time , Because of the app.js file will be execute again to create worker instance.
    }
    //  Event Register First Time
    // cluster.on('online', worker=>{
    //     console.log('Worker Online ', worker.id, ' Process Id ', worker.process.pid);
    // });
    // cluster.on('exit', worker=>{
    //     console.log('Worker Exit ', worker.id, ' Process Id ', worker.process.pid);
    // })
}
else{
    console.log(" I am a Worker ", cluster.isWorker);
    const app =express();
    app.use('/', require('./routes/route'));
    const server = app.listen(1234, err=>{
        if(err){
            console.log('Server Crash ', err);
        }
        else{
            console.log('Server Start ', server.address().port);
        }
    });
}