const express = require('express');
const route = express.Router();
route.get('/welcome',(req,res)=>{
    res.send('Welcome User');
})
route.get('/',(req, res)=>{
    // Make the Things Slow
    doSomeHeavyWork();
    res.send('Heavy Work Done....');
})
function doSomeHeavyWork(){
    for(let i = 1; i<=100000; i++){
        for(let j = 1; j<=500000; j++){
            
        }
    }
    console.log('Heavy Work Done...');
}
module.exports = route;