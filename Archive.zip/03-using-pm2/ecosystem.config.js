module.exports = {
  apps : [{
    name   : "my pm2 app",
    script : "./app.js",
    instances:"max",
    exec_mode:"cluster",
    arg:"Production Mode On", // Get Arg using process.argv
    watch:true, 
    max_memory_restart:"1G" // your app will be restarted if it exceeds the amount of memory specified. (it can be “10M”, “100K”, “2G” and so on)

  }]
}
