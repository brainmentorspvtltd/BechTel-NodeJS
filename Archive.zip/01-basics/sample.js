process.on('uncaughtError', err=>{
    console.log('Log the Error ', err);
})
process.on('exit',()=>{
    
})