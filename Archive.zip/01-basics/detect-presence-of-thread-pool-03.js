// I Have 8 Core Machines so All Run in Parallel Way , 
const fs = require('fs');
console.log("I am Running via Event Loop...");
let start = Date.now();
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('T1 Running  ', Date.now()-start);
        //console.log('Content is ', buffer.toString());
    }
});
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('T2 Running  ', Date.now()-start);
       // console.log('Content is ', buffer.toString());
    }
});
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('T3 Running  ', Date.now()-start);
        //console.log('Content is ', buffer.toString());
    }
});
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('T4 Running  ', Date.now()-start);
        //console.log('Content is ', buffer.toString());
    }
});
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('T5 Running  ', Date.now()-start);
        //console.log('Content is ', buffer.toString());
    }
});
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('T6 Running  ', Date.now()-start);
        //console.log('Content is ', buffer.toString());
    }
});
console.log('Event Loop Done.....');