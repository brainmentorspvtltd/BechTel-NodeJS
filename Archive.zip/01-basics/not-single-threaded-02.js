const fs = require('fs');
console.log("I am Running via Event Loop...");
fs.readFile(__filename,(err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('Running via Outside the Event Loop ');
        console.log('Content is ', buffer.toString());
    }
});
console.log('Event Loop Done.....');